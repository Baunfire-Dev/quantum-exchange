import './app.js';
import './global.js';
import './animation.js';
import './load.js';