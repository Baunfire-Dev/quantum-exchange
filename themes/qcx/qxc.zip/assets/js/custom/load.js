jQuery(document).ready(function () {
    window.baunfire.ready();
});

// jQuery(window).on("load", function () {
//     // window.baunfire.load();
// });