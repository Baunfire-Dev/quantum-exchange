<?php
return [
    "dependencies" => ["jquery", "bf-select-two-script"],
    "version" => _S_VERSION,
    "in_footer" => [
        "strategy" => "defer",
        "in_footer" => true
    ]
];
