<?php
return [
    "dependencies" => ["jquery"],
    "version" => _S_VERSION,
    "in_footer" => [
        "strategy" => "defer",
        "in_footer" => true
    ]
];
